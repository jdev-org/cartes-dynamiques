alter table fontaine.fontaine 
add url_jeu_vp VARCHAR (300);