#!/bin/sh

###################################################################
#Script Name	: update.sh
#Description	: push Eau de Paris geojson data in database
#Author       	: Gaetan B, Pierre J
#Email         	: pierre.jego@jdev.fr
###################################################################

NOW=$(date +"%Y-%m-%d")
LOGS=/var/fontaines/logs/$NOW.traces.log

echo $NOW >> $LOGS
echo "*** Start udpate***" >> $LOGS

RESULT=/var/fontaines/data/fontaine.json
RESULT_DIR=/var/fontaines/data/


echo " Récupération du fichier via SFTP " >> $LOGS
if sshpass -p "${SFTP_PWD}" sftp -o "HostKeyAlgorithms ssh-rsa" "sftp://${SFTP_USER}@${SFTP_URL}:${SFTP_PORT}/${FILENAME}" $RESULT; then
	
	echo "Integration des données dans la base" >> $LOGS
	PGPASSWORD=${POSTGRES_PASSWORD} psql -h ${POSTGRES_HOSTNAME} -U ${POSTGRES_USER} -d ${POSTGRES_DB} -c "DROP TABLE IF EXISTS fontaine.fontaine_tmp;"
	ogr2ogr -f "PostgreSQL" PG:"host=${POSTGRES_HOSTNAME} port=${POSTGRES_PORT} dbname=${POSTGRES_DB} user=${POSTGRES_USER} password=${POSTGRES_PASSWORD}" -lco SCHEMA=${SCHEMA} -lco OVERWRITE=YES $RESULT -nln fontaine_tmp -nlt POINT -s_srs "EPSG:2154" -t_srs "EPSG:4326"  >> $LOGS

	echo "Modification des données fontaine" >> $LOGS
	PGPASSWORD=${POSTGRES_PASSWORD} psql -h ${POSTGRES_HOSTNAME} -U ${POSTGRES_USER} -d ${POSTGRES_DB} -f /scripts/fontaine_update.sql

	echo "Modification des données" >> $LOGS
	PGPASSWORD=${POSTGRES_PASSWORD} psql -h ${POSTGRES_HOSTNAME} -U ${POSTGRES_USER} -d ${POSTGRES_DB} -c "update fontaine.fontaine set type_objet_lib='Fontaine des bois parcs et jardins' where type_objet_lib='Fontaine des bois, parcs et jardins';"
else
	echo "Erreur lors de la récupération du fichier, aucune données mise à jour"; >> $LOGS
fi;

echo " Récupération des fichiers commerces via SFTP " >> $LOGS
if sshpass -p "${SFTP_PWD}" sftp -o "HostKeyAlgorithms ssh-rsa" -r ${SFTP_USER}@${SFTP_URL}:/ $RESULT_DIR; then

	echo "Intégration du shp commerce en base de données" >> $LOGS
	PGPASSWORD=${POSTGRES_PASSWORD} psql -h ${POSTGRES_HOSTNAME} -U ${POSTGRES_USER} -d ${POSTGRES_DB} -c "DROP TABLE IF EXISTS fontaine.commerce_tmp;"
	PGCLIENTENCODING=LATIN1 ogr2ogr -f "PostgreSQL" PG:"host=${POSTGRES_HOSTNAME} port=${POSTGRES_PORT} dbname=${POSTGRES_DB} user=${POSTGRES_USER} password=${POSTGRES_PASSWORD}" -lco GEOMETRY_NAME=geom -lco SCHEMA=fontaine -lco OVERWRITE=YES -nln commerce_tmp -nlt MULTIPOINT -s_srs "EPSG:2154" -t_srs "EPSG:2154" "${RESULT_DIR}/COMMERCE.shp" >> $LOGS

	echo "Modification des données commerce" >> $LOGS
	PGPASSWORD=${POSTGRES_PASSWORD} psql -h ${POSTGRES_HOSTNAME} -U ${POSTGRES_USER} -d ${POSTGRES_DB} -f /scripts/commerce_update.sql
fi;

echo "***END SCRIPT***" >> $LOGS
